<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
  header("Location: /au project//alogin.html");
  exit;
}

// Database connection (replace with your credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "your_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get user details from the database
$email = $_SESSION['email']; // Assuming you store the email in the session after login
$sql = "SELECT * FROM customer_user WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
  // Display user profile
  $row = $result->fetch_assoc();
  
  echo "<div class='content-wrapper'>";
  echo "<u><h1 style='text-align:center'>Customer Profile</h1></u>";
    echo "<p>First Name: " . $row['first_name'] . "</p>";
    echo "<p>Last Name: " . $row['last_name'] . "</p>";

    // echo "<div class='user-info'>";
      echo "<p>Mobile: " . $row['mobile'] . "</p>";
      echo "<p>Email: " . $row['email'] . "</p>";
    // "</div>";

    echo "<div class='image-frame'>";
      // Check if there's an image URL before displaying
      if ($row['image_url'] != null && !empty($row['image_url'])) {
        echo "<img src='" . $row['image_url'] . "' alt='" . $row['first_name'] . " " . $row['last_name'] . " Profile Image'>";
      } else {
        echo "Profile image not available.";
      }
    echo "</div>";

    echo "<button type='submit' onclick='navigateToPage()' style='background-color: #007bff; color: white;'>SHOP</button>";
  echo "</div>";

  echo '<script>
    function navigateToPage() {
      window.location.href = "/au project/shopcategories.html";
    }
  </script>';

  // Do not display password for security reasons
} else {
  echo "User not found.";
}

// Close connection
$conn->close();
?>

<style>
  /* Your CSS styles here */
  .content-wrapper {
    display: flex;
    flex-direction: column;
    align-items: center; /* Centers elements horizontally */
    justify-content: center; /* Centers elements vertically */
    width: 60%; /* Fills viewport width */
    margin: 0 auto; /* Centers horizontally in viewport */
    padding: 20px;
    background-color: #e4eef2; /* Light gray background */
  }

  .user-info {
    text-align: left; /* Align user information left */
    margin-bottom: 15px; /* Add some space below user information */
  }

  .image-frame {
    display: block;
    margin: 20px auto;
    width: 200px; /* Adjust width as needed */
    height: 180px; /* Adjust height as needed */
    border: 5px solid #ddd;
    border-radius: 50px;
    overflow: hidden;
    /* Adjust these properties for aspect ratio preservation */
    position: relative;
  }

  .image-frame img {
    width: 100%;
    height: auto;
    position: absolute;
    top: 0;
    left: 0;
  }

  /* Center the button horizontally */
  button {
    margin: 10px auto 0 auto; /* Add top margin and center horizontally */
    padding: 10px 20px; /* Add some padding for better text visibility */
    border: none; /* Remove default button border */
    border-radius: 5px; /* Add rounded corners */
    cursor: pointer; /* Change cursor to pointer on hover */
  }
  </style>