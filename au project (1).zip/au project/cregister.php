<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty ($_POST['first_name']) && !empty ($_POST['last_name']) && !empty ($_POST['mobile']) && isset ($_FILES["profile_image"]) && !empty ($_POST['email']) && !empty ($_POST['password'])) {
    $servername = "localhost"; // Change this to your server name
    $username = "root"; // Change this to your database username
    $password = ""; // Change this to your database password
    $dbname = "your_database"; // Change this to your database name

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die ("Connection failed: " . $conn->connect_error);
    }

    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $targetDir = "uploads/";
    $targetFile = $targetDir . basename($_FILES["profile_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["profile_image"]["tmp_name"]);
    if ($check !== false) {
        // File is an image
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Check if file already exists
    if (file_exists($targetFile)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["profile_image"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow only certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // If everything is ok, try to upload file
    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $targetFile)) {
            // Insert data info into database
            $imagePath = $targetFile;
            $sql = "INSERT INTO customer_user (first_name, last_name, mobile, image_url, email, password)
                    VALUES ('$first_name', '$last_name', '$mobile', '$imagePath', '$email', '$password')";

            if ($conn->query($sql) === TRUE) {
                // Redirect to login page
                header("Location: /au%20project/clogin.html");
                exit;
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    // SQL query to insert data into database

    // Close connection
    $conn->close();
} else {
    echo !empty ($_POST['first_name']);
    echo !empty ($_POST['last_name']);
    echo !empty ($_POST['mobile']);
    echo !empty ($_POST['password']);
    echo !empty ($_POST['email']);
    echo isset ($_FILES["profile_image"]);
    // If any required field is empty, display an error message
    echo "Error: All fields are required.";
}

?>