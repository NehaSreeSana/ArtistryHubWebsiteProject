<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost"; // Change this to your server name
    $username = "root"; // Change this to your database username
    $password = ""; // Change this to your database password
    $dbname = "your_database"; // Change this to your database name

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die ("Connection failed: " . $conn->connect_error);
    }
    $artist_name = $_POST['artist_name'];
    $painting = $_FILES['painting'];
    $date_time = $_POST['date_time'];
    $min_auction_price = $_POST['min_auction_price'];
    $targetDir = "auction_paintings/";
    $targetFile = $targetDir . basename($_FILES["painting"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["painting"]["tmp_name"]);
    if ($check !== false) {
        // File is an image
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Check if file already exists
    if (file_exists($targetFile)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["painting"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow only certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // If everything is ok, try to upload file
    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["painting"]["tmp_name"], $targetFile)) {
            // Insert data info into database
            $imagePath = $targetFile;

            $sql = "INSERT INTO  auction (artist_name, painting, date_time, min_auction_price)
      VALUES ('$artist_name', '$imagePath', '$date_time', '$min_auction_price')";

            if ($conn->query($sql) === TRUE) {
                // Redirect to login page
                header("Location: /au%20project/show_auctions.php");
                exit;
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    // SQL query to insert data into database

    // Close connection
    $conn->close();
} else {
    // If any required field is empty, display an error message
    echo "Error: All fields are required.";
}

?>