<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['painting_id'])) {
    // Check if the session variable exists, if not, initialize it as an empty array
    if (!isset($_SESSION['selected_cart_objects'])) {
        $_SESSION['selected_cart_objects'] = array();
    }

    // Decode the JSON string to get an array of selected painting IDs
    $selected_painting_ids = $_SESSION['selected_cart_objects'];

    // Get the new painting ID to remove
    $painting_id_to_remove = $_POST['painting_id'];

    // Remove the painting ID from the array
    $updated_painting_ids = array_diff($selected_painting_ids, array($painting_id_to_remove));

    // Update the session variable with the updated array
    $_SESSION['selected_cart_objects'] = $updated_painting_ids;

    // Output the updated array
    echo json_encode($_SESSION['selected_cart_objects']);

    // Output the count of selected items
    echo "Total selected items: " . count($_SESSION['selected_cart_objects']);
} else {
    // If painting ID is not provided or if the request method is not POST, output an error message
    echo "Error: Invalid request.";
}
?>
