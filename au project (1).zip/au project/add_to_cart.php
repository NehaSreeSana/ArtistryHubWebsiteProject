<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset ($_POST['painting_id'])) {
    // Check if the session variable exists, if not, initialize it as an empty array
    if (!isset ($_SESSION['selected_cart_objects'])) {
        $_SESSION['selected_cart_objects'] = array();
    }

    // Decode the JSON string to get an array of new painting IDs
    $new_painting_id = $_POST['painting_id'];

    // Append the new painting ID to the existing session array
    $_SESSION['selected_cart_objects'][] = $new_painting_id;

    // Remove duplicates
    $_SESSION['selected_cart_objects'] = array_unique($_SESSION['selected_cart_objects']);

    // You can optionally output a success message
    echo count($_SESSION['selected_cart_objects']);
} else {
    // If painting ID is not provided or if the request method is not POST, output an error message
    echo "Error: Invalid request.";
}
?>