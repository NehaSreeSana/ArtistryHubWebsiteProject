<?php

function getCartItemCount()
{
  if (isset ($_SESSION['selected_cart_objects'])) {
    return count($_SESSION['selected_cart_objects']);
  } else {
    return 0;
  }
}

// Database connection
$servername = "localhost"; // Change this to your server name
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "your_database"; // Change this to your database name
session_start();

if (!isset ($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
  // Redirect user to login page if not logged in
  header("Location: /au project/login.html");
  exit;
}

// Check if logout button is clicked
if (isset ($_POST['logout'])) {
  // Unset all session variables
  session_unset();
  // Destroy the session
  session_destroy();
  // Redirect to login page
  header("Location: /au project/login.html");
  exit();
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die ("Connection failed: " . $conn->connect_error);
}

if (isset ($_GET['type'])) {
  $type = $_GET['type'];
  $sql = "SELECT * FROM paintings WHERE art_type='$type' ORDER BY placement DESC";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // Output data of each row
    echo "<style>";
    echo ".container {
    display: flex;
    flex-wrap: wrap;
    margin: 20px;
    padding: 10px;
    background-color: #f5f5f5;
  }";

    echo ".item {
    flex: 0 0 25%;  
    margin: 10px;
    padding: 15px;
    border: 1px solid #ccc;
    text-align: center;
    background-color: #fff;
  }";

    echo ".id {
    color: magenta;
    font-size: 20px;
  }";

    echo "</style>";

    echo "<div class='container'>";
    while ($row = $result->fetch_assoc()) {
      $paintingId = $row["id"];
      $userId = $row["user_id"];

      // Get username of the artist
      $sql_user = "SELECT * FROM users WHERE id='$userId'";
      $userResult = $conn->query($sql_user);
      $username = '';
      if ($userResult->num_rows == 1) {
        $user = $userResult->fetch_assoc();
        $username = $user['first_name'] . ' ' . $user['last_name'];
      }

      echo "<div class='item'>";
      echo "<div class='id'>Painting ID: " . $row["id"] . "</div><br>";
      echo "Title: " . $row["title"] . "<br>";
      echo "Artist: " . $username . "<br>";
      echo " <img width='100' height='100' src='" . $row['featured_image'] . "'><br>";
      echo "price: " . $row["selling_price"] . "<br>";
      echo "<button onclick='addToCart($paintingId)'>Add To Cart</button><br><br>";
      echo "</div>";
    }
    echo "</div>";
    echo "Cart Items: <button id='cartButton' onclick='printCartItems()'>" . getCartItemCount() . "</button><br><br>";
  } else {
    echo "No paintings found.";
  }
} else {
  echo "No type selected";
}

// Close connection
$conn->close();
?>
<script>
  function addToCart(paintingId) {
    console.log(paintingId);
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "add_to_cart.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
      if (xhr.readyState == 4 && xhr.status == 200) {
        console.log(xhr.responseText);
        document.getElementById('cartButton').innerHTML = xhr.responseText;
      }
    };
    xhr.send("painting_id=" + paintingId);
  }
  function printCartItems() {

    window.location.href = '/au project/print_cart_items.php';
  }
</script>