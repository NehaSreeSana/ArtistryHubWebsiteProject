<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost"; // Change this to your server name
    $username = "root"; // Change this to your database username
    $password = ""; // Change this to your database password
    $dbname = "your_database"; // Change this to your database name

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $customer_name = $_POST['customer_name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $type_of_painting = $_POST['type_of_painting'];
    $quantity = $_POST['quantity'];
    $price_range = $_POST['price_range'];

    $sql = "INSERT INTO `bulk_order` (customer_name, mobile, email, type_of_painting, quantity, price_range)
      VALUES ('$customer_name', '$mobile', '$email', '$type_of_painting', '$quantity', '$price_range')";

    if ($conn->query($sql) === TRUE) {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Order Details</title>
            <style>
                .order-details {
                    width: 70%; /* Set width to 70% of the screen */
                    margin: 10px auto; /* Center the container horizontally */
                    border: 1px solid #ddd;
                    padding: 20px;
                    border-radius: 5px;
                    background-color: #f5f5f5;
                    text-align: center;
                }

                .order-details h2 {
                    font-size: 40px;
                    margin-bottom: 15px;
                    text-decoration: underline;
                }

                .order-details p {
                    margin-bottom: 5px;
                }

                .order-details p span {
                    font-weight: bold;
                }
            </style>
        </head>
        <body>
        <div class="order-details">
            <h2>Order Details</h2>
            <p><span>Customer Name:</span> <?php echo $customer_name; ?></p>
            <p><span>Mobile:</span> <?php echo $mobile; ?></p>
            <p><span>Email:</span> <?php echo $email; ?></p>
            <p><span>Type of Painting:</span> <?php echo $type_of_painting; ?></p>
            <p><span>Quantity:</span> <?php echo $quantity; ?></p>
            <p><span>Price Range:</span> <?php echo $price_range; ?></p>
            <p><span>Total Price:</span> <?php echo $price_range * $quantity; ?></p>
            <p><span>Discount:</span> 10%</p>
            <p><span>Final Price:</span> <?php echo ($price_range * $quantity * 10) / 100; ?></p>
        </div>
        </body>
        </html>
        <?php
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close connection
    $conn->close();
} else {
    // If any required field is empty, display an error message
    echo "Error: All fields are required.";
}
?>
