<?php
session_start();

// Check if user is logged in
if (!isset ($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Redirect user to login page if not logged in
    header("Location: /au project/alogin.html");
    exit;
}

// Database connection
$servername = "localhost"; // Change this to your server name
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "your_database"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die ("Connection failed: " . $conn->connect_error);
}

$email = $_SESSION['email']; // Assuming you store the email in the session after login
$sql = "SELECT * FROM users WHERE email='$email'";
$result = $conn->query($sql);
if ($result->num_rows == 1) {
    $orientation = $_POST['orientation'];
    $title = $_POST['title'];
    $featured_image = $_FILES['featured_image'];
    $size = $_POST['size'];
    $art_type = $_POST['art_type'];
    $art_medium = $_POST['art_medium'];
    $selling_price = $_POST['selling_price'];
    $description = $_POST['description'];
    $dimension = $_POST['dimension'];
    echo $orientation . '<br>';
    echo $title . '<br>';
    echo $featured_image . '<br>';
    echo $size . '<br>';
    echo $art_type . '<br>';
    echo $art_medium . '<br>';
    echo $selling_price . '<br>';
    echo $description . '<br>';
    echo $dimension . '<br>';


    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["featured_image"]["tmp_name"]);
    if ($check !== false) {
        // File is an image
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["featured_image"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    $targetDir = "uploads/";
    $targetFile = $targetDir . basename($_FILES["featured_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    // Allow only certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // If everything is ok, try to upload file
    if ($uploadOk == 1) {
        $row = $result->fetch_assoc();
        $user_id = $row['id'];
        if (move_uploaded_file($_FILES["featured_image"]["tmp_name"], $targetFile)) {
            // Insert data info into database
            $imagePath = $targetFile;
            echo $orientation;
            $sql = "INSERT INTO paintings (user_id, orientation, title, featured_image, size, art_type, art_medium, selling_price, description, dimension)
                    VALUES ('$user_id', '$orientation','$title','$imagePath','$size','$art_type','$art_medium','$selling_price','$description','$dimension')";

            if ($conn->query($sql) === TRUE) {
                // Redirect to login page
                header("Location: /au%20project/shopcategories.html");
                exit;
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
} else {
    header("Location: /au project/alogin.html");
}



// Get user details from the database
$conn->close();
?>