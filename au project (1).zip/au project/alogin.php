<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty ($_POST['password']) && !empty ($_POST['email'])) {
    $servername = "localhost"; // Change this to your server name
    $username = "root"; // Change this to your database username
    $password = ""; // Change this to your database password
    $dbname = "your_database"; // Change this to your database name

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die ("Connection failed: " . $conn->connect_error);
    }
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        session_start();
        $row = $result->fetch_assoc();
        $user_id = $row['id'];

        $_SESSION['loggedin'] = true;
        $_SESSION['email'] = $email;
        $_SESSION['user_id'] = $user_id;
        header("Location: /au project/aprofile.php");
        exit;
    } else {
        // Login failed
        echo "Invalid email or password.";
    }

    // SQL query to insert data into database

    // Close connection
    $conn->close();
} else {
    // If any required field is empty, display an error message
    echo "Error: All fields are required.";
}

?>