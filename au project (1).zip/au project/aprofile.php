<?php
session_start();

// Check if user is logged in
if (!isset ($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
  header("Location: /au project/alogin.html");
  exit;
}

// Database connection
$servername = "localhost"; // Change this to your server name
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "your_database"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die ("Connection failed: " . $conn->connect_error);
}

// Get user details from the database
$email = $_SESSION['email']; // Assuming you store the email in the session after login
$sql = "SELECT * FROM users WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
  // Display user details
  
  $row = $result->fetch_assoc();

  echo "<div class='container'>";
    echo "<div class='user-details'>";
      echo "<h2>Welcome, " . $row['first_name'] . "!</h2>";
      echo "<div class='detail-wrapper'><span>First Name:</span> " . $row['first_name'] ."</div>";
      echo "<div class='detail-wrapper'><span>Last Name:</span> " . $row['last_name'] . "</div>";
      echo "<div class='detail-wrapper'><span>Mobile:</span> " . $row['mobile'] . "</div>";
      echo "<div class='profile-image-wrapper'>";
        echo "<img width='100' height='100' src='" . $row['image_url'] . "' alt='Profile Image'>";
      echo "</div>";
      echo "<div class='detail-wrapper'><span>Email:</span> " . $row['email'] . "</div>";
      echo "<button type='submit' class='add-painting-btn' onclick='navigateToPage()'>Add Painting</button>";
    echo "</div>";
  echo "</div>";
  
  echo '<script>
  function navigateToPage() {
    window.location.href = "/au project/addpainting.html";
  }
</script>';
  // Do not display password for security reasons
} else {
  echo "User not found.";
}

// Close connection
$conn->close();
?>

<style>
  /* Basic layout styles */
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
  }

  .container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background-color: #f0f0f0;
  }

  /* User details section styles */
  .user-details {
    background-color: #fff;
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    text-align: center;
    width: 400px;
  }

  h2 {
    margin-bottom: 20px;
  }

  .detail-wrapper {
    margin-bottom: 10px;
    font-weight: bold;
  }

  .profile-image-wrapper {
    margin: 20px auto;
    border: 5px solid #ddd;
    border-radius: 80%;
    overflow: hidden;
  }

  /* Button styles */
  .add-painting-btn {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 10px auto;
    cursor: pointer;
    border-radius: 5px;
  }
</style>
