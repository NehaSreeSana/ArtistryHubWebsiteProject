-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2024 at 08:12 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `your_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `auction`
--

CREATE TABLE `auction` (
  `id` int(11) NOT NULL,
  `artist_name` text NOT NULL,
  `painting` text NOT NULL,
  `date_time` datetime NOT NULL,
  `min_auction_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auction`
--

INSERT INTO `auction` (`id`, `artist_name`, `painting`, `date_time`, `min_auction_price`) VALUES
(1, 'Nothing', 'Array', '2024-03-23 10:39:00', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `auction_data`
--

CREATE TABLE `auction_data` (
  `id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bid_amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auction_data`
--

INSERT INTO `auction_data` (`id`, `auction_id`, `user_id`, `bid_amount`) VALUES
(10, 1, 1, 100);

-- --------------------------------------------------------

--
-- Table structure for table `bulk_order`
--

CREATE TABLE `bulk_order` (
  `id` int(11) NOT NULL,
  `customer_name` text NOT NULL,
  `mobile` int(11) NOT NULL,
  `email` text NOT NULL,
  `type_of_painting` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `price_range` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bulk_order`
--

INSERT INTO `bulk_order` (`id`, `customer_name`, `mobile`, `email`, `type_of_painting`, `quantity`, `price_range`) VALUES
(1, 'Vignesh', 2147483647, 'vtest@test.com', 'watercolor', 100, 1000),
(2, 'Vignesh', 2147483647, 'vtest@test.com', 'watercolor', 100, 1000),
(3, 'Vignesh', 2147483647, 'vtest@test.com', 'watercolor', 100, 1000),
(4, 'Vignesh', 2147483647, 'vtest@test.com', 'watercolor', 100, 1000),
(5, 'Vignesh', 2147483647, 'vtest@test.com', 'watercolor', 100, 1000),
(6, 'Vignesh', 2147483647, 'vtest@test.com', 'watercolor', 100, 1000);

-- --------------------------------------------------------

--
-- Table structure for table `customer_user`
--

CREATE TABLE `customer_user` (
  `id` int(11) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `image_url` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `mobile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_user`
--

INSERT INTO `customer_user` (`id`, `first_name`, `last_name`, `image_url`, `email`, `password`, `mobile`) VALUES
(1, 'UdayKumar', 'CHITTIBOYINA', 'uploads/Screenshot_20230128_121615.png', 'udaykumar.udaykumar009@gmail.com', '123456', '9502732758'),
(2, 'sneha', 'yellumahanti', 'uploads/Screenshot 2024-03-22 154513.png', 'sneha@gmail.com', '123456', '01234567890'),
(3, 'gfchj', 'gfchj', 'uploads/student.png', 'dxcgfhj@gmail.com', 'fcghb', 'gfchj');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `creator_name` text NOT NULL,
  `task` text NOT NULL,
  `place` text NOT NULL,
  `description` text NOT NULL,
  `prize` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `guest_names` text NOT NULL,
  `rules` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `creator_name`, `task`, `place`, `description`, `prize`, `time`, `guest_names`, `rules`) VALUES
(1, 'Vignesh', '6578', '65789', 'fcgvhbjtrfygvhbjk', 1000, '2024-03-28 12:30:00', 'Harsha, Mohan', 'rdctfvghbjfctgvhj');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `image_path` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`image_path`) VALUES
('uploads/Screenshot 2024-03-20 123018.png');

-- --------------------------------------------------------

--
-- Table structure for table `paintings`
--

CREATE TABLE `paintings` (
  `id` int(11) NOT NULL,
  `user_id` text NOT NULL,
  `orientation` text NOT NULL,
  `title` text NOT NULL,
  `featured_image` text NOT NULL,
  `size` text NOT NULL,
  `art_type` text NOT NULL,
  `art_medium` text NOT NULL,
  `selling_price` int(11) NOT NULL,
  `description` text NOT NULL,
  `dimension` text NOT NULL,
  `placement` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paintings`
--

INSERT INTO `paintings` (`id`, `user_id`, `orientation`, `title`, `featured_image`, `size`, `art_type`, `art_medium`, `selling_price`, `description`, `dimension`, `placement`) VALUES
(9, '6', 'portrait', 'waterfall', 'uploads/Screenshot 2024-03-20 123018.png', '', '', '', 50, 'beautiful waterfall', '12*10', 1),
(10, '1', '', 'hgyfvb', 'uploads/Screenshot_20230109_111017.png', '', '', '', 5467, 'trfghjhg', '67', 0),
(11, '6', '', 'qwertyu', 'uploads/Screenshot 2024-03-21 235816.png', '', '', '', 10, 'nothing', '100*120', 0),
(12, '6', '', 'sclupture', 'uploads/img7.jpeg', '', '', '', 100000, 'antient sclupture', '50*40', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sponsor`
--

CREATE TABLE `sponsor` (
  `id` int(11) NOT NULL,
  `artist_name` text NOT NULL,
  `painting` text NOT NULL,
  `sponsor_name` text NOT NULL,
  `sponsor_amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sponsor`
--

INSERT INTO `sponsor` (`id`, `artist_name`, `painting`, `sponsor_name`, `sponsor_amount`) VALUES
(3, 'fdxcv', 'qwertyu', 'dfcghj', 54678),
(4, 'szdxfgchj', 'waterfall', 'dfxcghj', 5467);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `image_url` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `mobile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `image_url`, `email`, `password`, `mobile`) VALUES
(1, 'Vignesh', 'Koyilada', 'uploads/1.jpg', 'vtest@test.com', 'Welcome@123', '9876543'),
(2, 'uday', 'chittiboyina', 'uploads/Screenshot 2024-03-20 130913.png', 'udaykumar.udaykumar009@gmail.com', '123456', '9502732758'),
(3, 'uday', 'chittiboyina', 'uploads/Screenshot 2024-03-20 114715.png', 'udaykumar.udaykumar009@gmail.com', '123456', '+919502732758'),
(4, 'Chittuboyina uday', 'Kumar', 'uploads/Screenshot_20230128_121615.png', 'udaykumar.udaykumar009@gmail.com', '123456', '7330954718'),
(5, 'charan', 'chittiboyina', 'uploads/Screenshot_20230109_111100.png', 'charan@gmail.com', '123456', '7207680742'),
(6, 'neha sree', 'sana', 'uploads/Screenshot 2024-02-27 191559.png', 'neha@gmail.com', '123456', '9121647648'),
(7, 'sneha', 'yellumahanti', 'uploads/Screenshot 2024-03-20 130913.png', 'sneha@gmail.com', '123456', '1234567890'),
(8, 'sneha', 'yellumahanti', 'uploads/Screenshot 2023-06-21 162451.png', 'sneha@gmail.com', '123456', '1234567890'),
(9, 'UdayKumar', 'CHITTIBOYINA', 'uploads/udai.png', 'udaykumar.udaykumar009@gmail.com', '123456', '9502732758'),
(10, 'UdayKumar', 'CHITTIBOYINA', 'uploads/Screenshot 2024-03-20 123306.png', 'udaykumar.udaykumar009@gmail.com', '123456', '9502732758'),
(11, 'sneha', 'yellumahanti', 'uploads/img8.jpeg', 'sneha@gmail.com', '123456', '01234567890'),
(12, 'Vishwanath', 'Murtinty', 'uploads/img4.jpeg', 'viswa@gmail.om', '123456', '1234567890');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auction`
--
ALTER TABLE `auction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auction_data`
--
ALTER TABLE `auction_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bulk_order`
--
ALTER TABLE `bulk_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_user`
--
ALTER TABLE `customer_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paintings`
--
ALTER TABLE `paintings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sponsor`
--
ALTER TABLE `sponsor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auction`
--
ALTER TABLE `auction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `auction_data`
--
ALTER TABLE `auction_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `bulk_order`
--
ALTER TABLE `bulk_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customer_user`
--
ALTER TABLE `customer_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `paintings`
--
ALTER TABLE `paintings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `sponsor`
--
ALTER TABLE `sponsor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
