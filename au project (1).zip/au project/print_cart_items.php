<?php
session_start();

$servername = "localhost"; // Change this to your server name
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "your_database"; // Change this to your database name

if (!isset ($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Redirect user to login page if not logged in
    header("Location: /au project/alogin.html");
    exit;
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if (isset ($_SESSION['selected_cart_objects'])) {
    // Output the contents of the selected_cart_objects session variable
    $cartItems = $_SESSION['selected_cart_objects'];
    foreach ($cartItems as $item) {
        $sql_painting = "SELECT * FROM paintings WHERE id='$item'";
        $paintingResult = $conn->query($sql_painting);
        $username = '';
        echo $item . "<br>";
        $row = $paintingResult->fetch_assoc();
        $email = $_SESSION['email'];
        $sql_user = "SELECT * FROM users WHERE email='$email'";
        $userResult = $conn->query($sql_user);
        $username = '';
        if ($userResult->num_rows == 1) {
            $user = $userResult->fetch_assoc();
            $username = $user['first_name'] . ' ' . $user['last_name'];
        }

        echo "Painting ID: " . $row["id"] . "<br>";
        echo "Title: " . $row["title"] . "<br>";
        echo "Artist: " . $username . "<br>";
        echo "Profile Image: <img width='100' height='100' src='" . $row['featured_image'] . "'><br>";
        echo "price: " . $row["selling_price"] . "<br>";
        $paintingId = $row["id"];
        echo "<button onclick='addToCart($paintingId)'> remove from cart </button><br><br>";
        echo "<button onclick=\"window.location.href = 'http://google.com';\">Buy</button><br><br>";
    }
} else {
    echo "No items in the cart.";
}

?>
<script>
    function addToCart(paintingId) {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "remove_from_cart.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                console.log(xhr.responseText);
                window.location.reload();
            }
        };
        xhr.send("painting_id=" + paintingId);
    }
</script>