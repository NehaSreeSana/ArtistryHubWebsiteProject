<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "your_database"; // Change this to your database name
session_start();
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if (!isset ($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Redirect user to login page if not logged in
    header("Location: /au project/login.html");
    exit;
}

// Check connection
if ($conn->connect_error) {
    die ("Connection failed: " . $conn->connect_error);
}

// Check if event ID is provided in the query parameter
if (isset ($_GET['auction_id'])) {
    $auction_id = $_GET['auction_id'];

    // SQL query to retrieve auction data for the specified event
    $sql_auction = "SELECT * FROM auction WHERE id = $auction_id";
    $result_auction = $conn->query($sql_auction);

    if ($result_auction->num_rows == 1) {
        // Display auction data
        $auction_data = $result_auction->fetch_assoc();
        echo "<h2>Auction Data for Event ID: $auction_data</h2>";
        echo "<div class=''>Artist Name: " . $auction_data['artist_name'] . "</div><br>";
        echo "<div class=''>Painting: <img src='" . $auction_data['painting'] . "'></img><br>";
        echo "<div class=''>Date Time: " . $auction_data['date_time'] . "</div><br>";
        echo "<div class=''>Minimum auction price: " . $auction_data['min_auction_price'] . "</div><br>";

        // SQL query to retrieve bid amounts for the specified event
        $sql_bids = "SELECT * FROM auction_data WHERE auction_id = $auction_id";
        $result_bids = $conn->query($sql_bids);

        if ($result_bids->num_rows > 0) {
            // Display bid amounts in a table
            echo "<h2>Bid Amounts for Event ID: $auction_id</h2>";
            echo "<table border='1'>";
            echo "<tr><th>Bid ID</th><th>Amount</th></tr>";
            while ($row = $result_bids->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["bid_amount"] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "No bids found for this event.";
        }

        // Form to submit bid amount
        echo '<form method="post" action="">
                <input type="text" name="bid_amount" placeholder="Enter Bid Amount">
                <input type="submit" name="submit" value="Submit Bid">
              </form>';

        // Handling form submission
        if (isset ($_POST['submit']) && isset ($_POST['bid_amount']) && $_POST['bid_amount'] !== '') {
            $bid_amount = $_POST['bid_amount'];
            $auction_id = $_GET['auction_id'];
            $user_id = $_SESSION['user_id'];

            $sql_check_bid = "SELECT * FROM auction_data WHERE auction_id = '$auction_id' AND user_id = '$user_id'";
            $result_check_bid = $conn->query($sql_check_bid);

            if ($result_check_bid->num_rows > 0) {
                echo "You have already submitted a bid for this auction.";
            } else {
                $sql = "INSERT INTO auction_data (auction_id, user_id, bid_amount) VALUES ('$auction_id',1, '$bid_amount')";
                if ($conn->query($sql) === TRUE) {
                    echo "Bid amount inserted successfully.";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }

            // Insert bid amount into the database
        }

    } else {
        echo "Auction data not found for this event.";
    }
} else {
    echo "Event ID is missing in the query parameter.";
}

// Close connection
$conn->close();
?>