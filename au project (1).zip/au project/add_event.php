<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost"; // Change this to your server name
    $username = "root"; // Change this to your database username
    $password = ""; // Change this to your database password
    $dbname = "your_database"; // Change this to your database name

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die ("Connection failed: " . $conn->connect_error);
    }
    $creator_name = $_POST['creator_name'];
    $task = $_POST['task'];
    $place = $_POST['place'];
    $description = $_POST['description'];
    $prize = $_POST['prize'];
    $time = $_POST['time'];
    $guest_names = $_POST['guest_names'];
    $rules = $_POST['rules'];

    $sql = "INSERT INTO  events (creator_name, task, place, description, prize, time, guest_names, rules)
      VALUES ('$creator_name', '$task', '$place', '$description', '$prize', '$time', '$guest_names', '$rules')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to login page
        header("Location: /au%20project/show_events.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    // SQL query to insert data into database

    // Close connection
    $conn->close();
} else {
    // If any required field is empty, display an error message
    echo "Error: All fields are required.";
}

?>