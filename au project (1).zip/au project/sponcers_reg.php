<?php
// MySQLi connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "your_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die ("Connection failed: " . $conn->connect_error);
}

// Table name
$table_name = "paintings";

// Query to get table structure
$sql = "SELECT * FROM $table_name";
$result = $conn->query($sql);

// Array to store column names
$options = array();

// Check if query was successful
if ($result->num_rows > 0) {
    // Fetch each row
    while ($row = $result->fetch_assoc()) {
        // Get value of the specified key
        $value = $row['title'];
        // Add value to array
        $options[] = $value;
    }
} else {
    echo "No data found in table";
}

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Event Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            font-weight: bold;
            color: #666;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="file"],
        select {
            width: calc(100% - 22px);
            /* Adjusted width to account for padding */
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .error-message {
            color: red;
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Sponcer ?</h2>
        <form action="add_sponser.php" method="post" id="eventForm" onsubmit="return validateForm()"
            enctype="multipart/form-data">
            <label for="artistName">Artist Name:</label>
            <input type="text" id="artistName" name="artist_name" required>
            <label for="painting">Upload Painting:</label>
            <select id="size" name="painting">
                <?php
                foreach ($options as $column) {
                    echo "<option value=\"$column\">$column</option>";
                }
                ?>
            </select>
            <label for="sponsorName">Sponsor Name:</label>
            <input type="text" id="sponsorName" class="input" name="sponsor_name" required>
            <label for="sponsoredAmount">Sponsored Amount:</label>
            <input type="text" id="sponsoredAmount" name="sponsor_amount" required>
            <input type="submit" value="Submit">
        </form>
    </div>
    <script>
        function validateForm() {
            var artistName = document.getElementById("artistName").value;
            var sponsorName = document.getElementById("sponsorName").value;
            var painting = document.getElementById("painting").value;
            var sponsoredAmount = document.getElementById("sponsoredAmount").value;

            var errorMessage = "";

            if (artistName.trim() === "") {
                errorMessage += "Artist Name is required\n";
            }
            if (painting.trim() === "") {
                errorMessage += "Painting is required\n";
            }
            if (sponsorName.trim() === "") {
                errorMessage += "Sponsor Name is required\n";
            }
            if (sponsoredAmount.trim() === "") {
                errorMessage += "Sponsored Amount is required\n";
            }

            if (errorMessage !== "") {
                alert(errorMessage);
                return false;
            }

            return true;
        }
    </script>
</body>

</html>