function show3DView() {
    // Check if browser supports WebGL
    if (!Detector.webgl) {
      alert("Your browser does not support WebGL. 3D view is not available.");
      return;
    }
  
    // Replace this with your actual 3D content logic (e.g., a library like Three.js)
    alert("3D view is currently under development. Stay tuned!");
  }
  