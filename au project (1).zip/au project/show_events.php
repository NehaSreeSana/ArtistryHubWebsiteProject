<?php

function getCartItemCount()
{
  if (isset($_SESSION['selected_cart_objects'])) {
    return count($_SESSION['selected_cart_objects']);
  } else {
    return 0;
  }
}

// Database connection (replace with your credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "your_database";
session_start();

// Check if logout button is clicked
if (isset($_POST['logout'])) {
  // Unset all session variables
  session_unset();
  // Destroy the session
  session_destroy();
  // Redirect to login page
  header("Location: /au project/login.html");
  exit();
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// SQL query to select all events
$sql = "SELECT * FROM events";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // Output data of each row
  echo "<style>";
  echo "h1 { /* Style the Events heading */
    font-weight: bold; /* Make text bold */
    text-align: center; /* Center the heading */
  }";

  echo ".container {
    display: flex; /* Make events container a flexbox */
    justify-content: center; /* Center event items horizontally */
    align-items: center; /* Center event items vertically (optional) */
    flex-wrap: wrap; /* Allow events to wrap on multiple lines */
    margin: 20px;
    padding: 10px;
    background-color: #f5f5f5;
  }";

  echo ".event-item { /* Style each event item */
    flex: 0 0 30%;  /* Set width to 30% of container */
    margin: 10px;
    padding: 15px;
    border: 1px solid #ccc;
    text-align: center;
    background-color: #fff;
  }";

  echo ".event-id {
    color: magenta; /* Style event ID text */
    font-size: 20px;
  }";

  echo "</style>";

  echo "<h1>Events</h1>"; // Added the Events heading

  echo "<div class='container'>";
  while ($row = $result->fetch_assoc()) {
    echo "<div class='event-item'>";
    echo "<div class='event-id'>Event Id: " . $row["id"] . "</div><br>";
    echo "Creator Name: " . $row['creator_name'] . "<br>";
    echo "Task: " . $row['task'] . "<br>";
    echo "Place: " . $row['place'] . "<br>";
    echo "Description: " . $row['description'] . "<br>";
    echo "Prize: " . $row['prize'] . "<br>";
    echo "Time: " . $row['time'] . "<br>";
    echo "Guest Names: " . $row['guest_names'] . "<br>";
    echo "Rules: " . $row['rules'] . "<br><br>";
    echo "</div>";
  }
  echo "</div>";
} else {
  echo "No events found.";
}

// Close connection
$conn->close();
?>
<form method="post" action="">
  <input type="submit" name="logout" value="Logout">
</form>
