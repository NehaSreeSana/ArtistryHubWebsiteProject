<style>
    .container {
        display: flex;
        flex-wrap: wrap;
        margin: 20px;
        padding: 10px;
        background-color: #f5f5f5;
    }

    .item {
        flex: 0 0 25%;
        margin: 10px;
        padding: 15px;
        border: 1px solid #ccc;
        text-align: center;
        background-color: #fff;
    }
</style>
<?php
// Database connection
$servername = "localhost"; // Change this to your server name
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "your_database"; // Change this to your database name
session_start();

if (!isset ($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Redirect user to login page if not logged in
    header("Location: /au project/login.html");
    exit;
}

// Check if logout button is clicked
if (isset ($_POST['logout'])) {
    // Unset all session variables
    session_unset();
    // Destroy the session
    session_destroy();
    // Redirect to login page
    header("Location: /au project/login.html");
    exit();
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die ("Connection failed: " . $conn->connect_error);
}

// SQL query to select all events
$sql = "SELECT * FROM auction";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    echo '<div class="container">';
    while ($row = $result->fetch_assoc()) {
        echo "<div class='item'>";
        echo "Auction Id: " . $row["id"] . "<br>";
        echo "Artist Name: " . $row['artist_name'] . "<br>";
        echo "Painting: " . $row['painting'] . "<br>";
        echo "Painting: <img src='" . $row['painting'] . "'></img><br>";
        echo "Date Time: " . $row['date_time'] . "<br>";
        echo "Minimum auction price: " . $row['min_auction_price'] . "<br>";
        echo "<button onclick='bidOnEvent(" . $row['id'] . ")'>Bid</button><br>";
        echo "<br>";
        echo '</div>';
    }
    echo '</div>';
} else {
    echo "No events found.";
}

// Close connection
$conn->close();
?>
<style>
    .id {
        color: blue;
        font-size: 20px;
    }
</style>
<form method="post" action="">
    <input type="submit" name="logout" value="Logout">
</form>

<script>
    function bidOnEvent(eventId) {
        window.location.href = '/au project/bid.php?auction_id=' + eventId;
    }
</script>